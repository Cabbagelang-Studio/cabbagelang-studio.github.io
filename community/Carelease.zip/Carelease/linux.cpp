#include<unistd.h>
int main(){
	system("./cabbage main.cbg");
	return 0;
} 
