g++ linux.cpp -o main -m32
