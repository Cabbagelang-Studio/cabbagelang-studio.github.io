# coding:utf-8

import socket
import re
try:
    with open("port.val","r",encoding="utf-8") as file:
        port=int(file.read())
except:
    port=8000
try:
    with open("encoding.val","r",encoding="utf-8") as file:
        coding=file.read()
except:
    coding=coding
from multiprocessing import Process

# Root dir
HTML_ROOT_DIR = "./html"


def handle_client(client_socket):
    # Get client's response.
    request_data = client_socket.recv(1024)
    print("request data:", request_data)
    request_lines = request_data.splitlines()
    with open("request.val","w") as file:
        file.write("")
    for line in request_lines:
        with open("request.val","ab") as file:
            file.write(line)
        with open("request.val","a") as file:
            file.write("\n")
    # json request.
    request_start_line = request_lines[0]
    # Get the response of the user's request.
    file_name = re.match(r"\w+ +(/[^ ]*) ", request_start_line.decode(coding)).group(1)

    if "/" == file_name:
        file_name = "/index.html"

    # Open file and read it.
    try:
        file = open(HTML_ROOT_DIR + file_name, "rb")
    except IOError:
        response_start_line = "HTTP/1.1 404 Not Found\r\n"
        response_headers = "Server: My server\r\n"
        response_body = "<h1>404 Not Found!</h1>"
    else:
        file_data = file.read()
        file.close()

        # Build response data.
        response_start_line = "HTTP/1.1 200 OK\r\n"
        response_headers = "Server: My server\r\n"
        response_body = file_data.decode(coding)

    response = response_start_line + response_headers + "\r\n" + response_body
    print("response data:", response)

    # Return response.
    client_socket.send(bytes(response, coding))

    # Close connect.
    client_socket.close()


if __name__ == "__main__":
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(("", port))
    server_socket.listen(128)

    while True:
        client_socket, client_address = server_socket.accept()
        print("[%s, %s]User conneted." % client_address)
        handle_client_process = Process(target=handle_client, args=(client_socket,))
        handle_client_process.start()
        client_socket.close()
