#include <fstream>
using namespace std;
int main(int argc,char** argv){
	if (argc==1){
		return 0;
	}string self=argv[1];
	ifstream in((self+"/address.val").data());
	string address;
	in>>address;
	address=address+".val";
	in.close();
	in.open(address.data());
	string content;
	in>>content;
	in.close();
	ofstream out((self+"/content.val").data());
	out<<content;
	out.close();
}
